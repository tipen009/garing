Installation  <br> 
git clone https://github.com/virojano19/SKANTIJS  <br> 
cd SKANTIJS <br> 
python3 -m pip install -r requirements.txt  <br> 
nano  kicker.py<br> 
python3 kicker.py  <br> 
